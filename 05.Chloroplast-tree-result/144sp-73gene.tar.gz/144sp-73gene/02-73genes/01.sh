#!/bin/bash

# 创建目标目录（如果不存在）
mkdir -p 73-sp

# 遍历所有.fa文件
for f in *.fa; do
    # 统计序列数量（以>开头）
    count=$(grep -c '^>' "$f")
    
    # 如果数量大于100，则创建软连接
    if [ "$count" -gt 73 ]; then
        ln -s "$(pwd)/$f" "73-sp/$f"
        echo "Linked $f with $count sequences"
    fi
done
