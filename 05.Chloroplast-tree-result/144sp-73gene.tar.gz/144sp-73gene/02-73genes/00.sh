#!/bin/bash
infile="all.chl-new.fa"  # 替换为你的fa文件名

awk '/^>/{ 
    split($0, a, "[_|]"); 
    gene=a[2]; 
    out=gene".fa"; 
    print $0 > out; 
    next 
} 
{ print >> out }' "$infile"
