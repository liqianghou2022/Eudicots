#!/usr/bin/env python3
from Bio import SeqIO
import glob

# 所有FASTA文件，按文件名排序保证顺序一致
fa_files = sorted(glob.glob("*.fas"))

# 获取所有物种名（假设每个FASTA都有至少一条序列）
species_set = set()
for f in fa_files:
    for rec in SeqIO.parse(f, "fasta"):
        sp = rec.id.split("_")[0]  # 取第一个*作为物种名
        species_set.add(sp)

species_list = sorted(list(species_set))  # 按字母顺序（或自定义顺序）

# 初始化每个物种的超级序列字典
superseq = {sp: "" for sp in species_list}

# 遍历每个FA文件，将对应物种的序列拼接
for f in fa_files:
    # 记录当前文件中物种对应的序列
    seq_dict = {}
    for rec in SeqIO.parse(f, "fasta"):
        sp = rec.id.split("_")[0]
        seq_dict[sp] = str(rec.seq).upper()  # 大写

    # 当前文件每个物种的序列长度
    seqlen = max(len(s) for s in seq_dict.values()) if seq_dict else 0

    # 拼接到超级序列，不存在的用'-'填充
    for sp in species_list:
        seq = seq_dict.get(sp, "-" * seqlen)
        superseq[sp] += seq

# 输出最终超级基因FASTA
with open("supermatrix.fa", "w") as out:
    for sp in species_list:
        out.write(f">{sp}\n{superseq[sp]}\n")
